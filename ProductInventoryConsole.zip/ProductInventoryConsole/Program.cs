﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProductInventoryConsole
{
    class Program
    {
        static void Main(string[] args)
        {
            Product p1 = new Product(1, "Mango", 50, 10);
            Product p2 = new Product(2, "Banana", 100, 5);
            Product p3 = new Product(3, "Apple", 200, 10);
            Inventory i = new Inventory();
            i.AddProduct(p1);
            i.AddProduct(p2);
            i.AddProduct(p3);
            Console.WriteLine("Inventory Value: "+ i.InventoryValue());
        }
    }
}
