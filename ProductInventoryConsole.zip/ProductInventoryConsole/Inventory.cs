﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProductInventoryConsole
{
    class Inventory
    {
        public Product p { get; set; }
       // Product[] arrP = new Product[5];
        List<Product> p1 = new List<Product>(); 
        //static int productCount = 0;
        //public Inventory(Product p)
        //{
        //    this.p = p;
        //    productCount++;
        //}

        public void AddProduct(Product p)
        {
            p1.Add(p);
        }

        public double InventoryValue()
        {
            double finalValue = 0;
            foreach (var i in p1)
            {
                finalValue += i.quantity * i.price;
            }
            return finalValue;
        }
    }
}
