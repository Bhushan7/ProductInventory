﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProductInventoryConsole
{
    class Product
    {
        public int id { get; set; }
        public string name { get; set; }
        public int quantity { get; set; }
        public int price { get; set; }
        public Product(int id, string name, int quantity, int price)
        {
            this.id = id;
            this.name = name;
            this.quantity = quantity;
            this.price = price;
        }
    }
}
